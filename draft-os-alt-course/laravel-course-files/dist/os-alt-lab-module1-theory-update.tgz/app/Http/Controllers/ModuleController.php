<?php

namespace App\Http\Controllers;

use App\Models\Learner;
use App\Support\CourseModuleMeta;
use App\Services\CourseScoringService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ModuleController extends Controller
{
    public function __construct(
        private CourseScoringService $scoring
    ) {}

    protected function learner(): Learner
    {
        return Learner::findOrFail(session('learner_id'));
    }

    /**
     * @return array<int, array{q:string,a:array,c:int}>
     */
    protected function questions(int $moduleId, string $kind): array
    {
        return config('course.module_quizzes.'.$moduleId.'.'.$kind, []);
    }

    /**
     * @param  array<int, array{q:string,a:array,c:int}>  $questions
     */
    protected function scorePercent(array $questions, Request $request, string $prefix): int
    {
        if (count($questions) === 0) {
            return 0;
        }
        $correct = 0;
        foreach (array_keys($questions) as $i) {
            $v = (int) $request->input($prefix.$i);
            if (isset($questions[$i]['c']) && $v === (int) $questions[$i]['c']) {
                $correct++;
            }
        }

        return (int) round(100 * $correct / count($questions));
    }

    public function hub(int $module): View
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $meta = CourseModuleMeta::resolved($module);
        $p = $this->learner()->progressFor($module);

        return view('modules.hub', [
            'module' => $module,
            'meta' => $meta,
            'progress' => $p,
            'percent' => $this->scoring->moduleProgressPercent($p),
        ]);
    }

    public function theory(int $module): View
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $meta = CourseModuleMeta::resolved($module);

        return view('modules.theory', [
            'module' => $module,
            'meta' => $meta,
            'progress' => $this->learner()->progressFor($module),
        ]);
    }

    public function markTheoryRead(int $module): RedirectResponse
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $p = $this->learner()->progressFor($module);
        $p->theory_read_at = now();
        $p->save();

        return redirect()->route('modules.hub', $module)->with('ok', 'Теория отмечена как просмотренная.');
    }

    public function theoryQuizShow(int $module): View
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $qs = $this->questions($module, 'theory_quiz');

        return view('modules.theory-quiz', [
            'module' => $module,
            'meta' => CourseModuleMeta::resolved($module),
            'questions' => $qs,
            'progress' => $this->learner()->progressFor($module),
        ]);
    }

    public function theoryQuizSubmit(Request $request, int $module): RedirectResponse
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $qs = $this->questions($module, 'theory_quiz');
        $p = $this->learner()->progressFor($module);
        $p->theory_quiz_attempts = (int) $p->theory_quiz_attempts + 1;
        $score = $this->scorePercent($qs, $request, 'q');
        $p->theory_quiz_best_score = max((int) $p->theory_quiz_best_score, $score);
        if ($score >= CourseScoringService::PASS_THRESHOLD) {
            $p->theory_quiz_passed = true;
        }
        $p->save();

        return redirect()->route('modules.hub', $module)->with(
            $score >= CourseScoringService::PASS_THRESHOLD ? 'ok' : 'err',
            $score >= CourseScoringService::PASS_THRESHOLD
                ? 'Тест по теории сдан ('.$score.'%).'
                : 'Нужно набрать не менее '.CourseScoringService::PASS_THRESHOLD.'%. Сейчас: '.$score.'%.'
        );
    }

    public function practiceShow(int $module): View
    {
        abort_unless($module >= 1 && $module <= 10, 404);

        return view('modules.practice', [
            'module' => $module,
            'meta' => CourseModuleMeta::resolved($module),
            'progress' => $this->learner()->progressFor($module),
        ]);
    }

    public function practiceDone(int $module): RedirectResponse
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $p = $this->learner()->progressFor($module);
        $p->practice_done_at = now();
        $p->save();

        return redirect()->route('modules.hub', $module)->with('ok', 'Практика отмечена как выполненная.');
    }

    public function examShow(int $module): View
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $qs = $this->questions($module, 'module_exam');

        return view('modules.exam', [
            'module' => $module,
            'meta' => CourseModuleMeta::resolved($module),
            'questions' => $qs,
            'progress' => $this->learner()->progressFor($module),
        ]);
    }

    public function examSubmit(Request $request, int $module): RedirectResponse
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $qs = $this->questions($module, 'module_exam');
        $p = $this->learner()->progressFor($module);
        $p->module_exam_attempts = (int) $p->module_exam_attempts + 1;
        $score = $this->scorePercent($qs, $request, 'e');
        $p->module_exam_best_score = max((int) $p->module_exam_best_score, $score);
        if ($score >= CourseScoringService::PASS_THRESHOLD) {
            $p->module_exam_passed = true;
        }
        $p->save();

        return redirect()->route('modules.hub', $module)->with(
            $score >= CourseScoringService::PASS_THRESHOLD ? 'ok' : 'err',
            $score >= CourseScoringService::PASS_THRESHOLD
                ? 'Итоговый тест модуля сдан ('.$score.'%).'
                : 'Нужно набрать не менее '.CourseScoringService::PASS_THRESHOLD.'%. Сейчас: '.$score.'%.'
        );
    }

    public function saveDifficulties(Request $request, int $module): RedirectResponse
    {
        abort_unless($module >= 1 && $module <= 10, 404);
        $p = $this->learner()->progressFor($module);
        $p->difficulty_flags = [
            'theory' => $request->boolean('d_theory'),
            'theory_quiz' => $request->boolean('d_theory_quiz'),
            'practice' => $request->boolean('d_practice'),
            'module_exam' => $request->boolean('d_module_exam'),
        ];
        $p->save();

        return redirect()->route('modules.hub', $module)->with('ok', 'Отметки о сложностях сохранены.');
    }
}
