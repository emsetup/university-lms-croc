<?php

namespace App\Support;

/**
 * Подмешивает содержимое файлов для полей конфига (например теория модуля 1 из snippets).
 * Нужен, чтобы при php artisan config:cache не "запекался" устаревший markdown в кэше.
 */
final class CourseModuleMeta
{
    public static function resolved(int $module): array
    {
        $meta = config('course.modules.'.$module);
        if (! is_array($meta)) {
            abort(404);
        }
        if (isset($meta['theory']) && is_string($meta['theory'])) {
            $meta['theory'] = self::resolveTheoryPlaceholder($meta['theory']);
        }

        return $meta;
    }

    public static function resolveTheoryPlaceholder(string $theory): string
    {
        if (str_starts_with($theory, '@snippet:')) {
            $file = substr($theory, 9);
            $path = config_path('snippets/'.$file);

            return is_readable($path) ? (string) file_get_contents($path) : '';
        }

        return $theory;
    }
}
