#!/usr/bin/env bash
# Запускать на ВМ из корня проекта Laravel после распаковки архива dist/os-alt-lab-module1-theory-update.tgz
# Пример: cd /var/www/os-alt-lab && tar -xzf /tmp/os-alt-lab-module1-theory-update.tgz && bash scripts/apply-on-stand.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ ! -f artisan ]]; then
  echo "Ошибка: artisan не найден. Запустите скрипт из дерева Laravel (ожидается $ROOT/artisan)."
  exit 1
fi
run_artisan() {
  if id www-data &>/dev/null && [[ -r artisan ]]; then
    sudo -u www-data php artisan "$@"
  else
    php artisan "$@"
  fi
}
run_artisan config:clear
run_artisan view:clear
run_artisan cache:clear
echo "Готово. При необходимости: sudo systemctl reload php*-fpm"
bash scripts/verify-module1-theory.sh
